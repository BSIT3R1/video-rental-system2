<?php
	include_once 'home.php';
?>


<section class="main-container">
	<div class="main-wrapper">
			<section>
				<li id="menu">
					<a class="create" href="create.php">CREATE TRANSACTION</a>
					<a class="view" href="view.php">VIEW TRANSACTION</a>
					<a class="update" href="update.php">UPDATE TRANSACTION</a>
					
				</li>
			</section>
			<h2>Update Transaction</h2><br/><br/>
	</div>
</section>

<section>

 <?php
        //connect to DB
$connection = mysql_connect('localhost', 'root', ''); 
mysql_select_db('vloginsystem2');


$query = "SELECT * FROM customer"; 
$result = mysql_query($query);
echo "<table border='1'>";
echo "<tr><td>Transaction ID</td><td>Date</td><td>Last Name</td><td>First Name</td><td>Video Name</td><td>Video Type</td><td>Price</td></tr>";
while($row = mysql_fetch_array($result))
  {
  echo "<tr><td>" . $row['cust_transid'] ."</td><td>" . $row['cust_date'] . "</td><td>" . $row['cust_custlast'] . "</td><td>" . $row['cust_custfirst'] . "</td><td>" . $row['cust_vidname'] . "</td><td>" . $row['cust_vidtype'] . "</td><td>" . $row['cust_price'] . "<a href = 'edit.php?edit=$row[cust_transid],$row[cust_date],$row[cust_custlast],$row[cust_custfirst],$row[cust_vidname],$row[cust_vidtype],$row[cust_price]'>EDIT</a> <a href = 'delete.php?delete=$row[cust_transid],$row[cust_date],$row[cust_custlast],$row[cust_custfirst],$row[cust_vidname],$row[cust_vidtype],$row[cust_price]'>DELETE</a></td></tr>";
  }
echo "</table>";
mysql_close();
?>
</section>