<?php
	include_once 'home.php';
?>


<section class="main-container">
	<div class="main-wrapper">
			<section>
				<li id="menu">
					<a class="create" href="create.php">CREATE TRANSACTION</a>
					<a class="view" href="view.php">VIEW TRANSACTION</a>
					<a class="update" href="update.php">UPDATE TRANSACTION</a>
				</li>
			</section>
	</div>
</section>

<section>

 <?php
        //connect to DB
$connection = mysql_connect('localhost', 'root', ''); 
mysql_select_db('vloginsystem2');


$query = "SELECT * FROM customer"; 
$result = mysql_query($query);
echo "<table border='1'>";
echo "<tr><td>Transaction ID</td><td>Date</td><td>Last Name</td><td>First Name</td><td>Video Name</td><td>Video Type</td><td>Price</td></tr>";
?>
<form action="update.php" method="POST"> 
Last Name : <input type="text" name="cust_custlast"><br/>
<input type="submit" name="UPDATE">	
</form>

<?php
	while ($row = mysql_fetch_array($result)) 
		echo "<li>$row[cust_transid]</li>.<li>$row[cust_custlast]</li><a href = 'edit.php?edit=$row[cust_transid]'>EDIT</a><a href = 'delete
	.php?delete=$row[cust_transid]'>DELETE</a>";
	?>