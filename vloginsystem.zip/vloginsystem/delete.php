<?php
	if (isset($_GET['delete']))
	{
		$cust_transid = $_GET['delete'];
		$sql = "DELETE FROM customer where cust_transid = '$cust_transid'";
		$result = mysql_query($sql) or die("FAILED".mysql_error());
 	echo "<meta http-equiv=refresh'content='0;url=update.php'>";
	}
?>