
<?php
	include_once 'home.php';
?>
<section class="main-container">
	<div class="main-wrapper">
			<link rel="stylesheet" href="css/style2.min.css">
	<link rel="stylesheet" href="style2.css">
		<h2>Video Rental System</h2>		
		<div id="Usermenu">
			<?php
				if(isset($_SESSION['u_id'])){
					echo "Hello, "
					, $_SESSION['u_uid'], "!"  ;
				}
			?>
		</div>
	</div>
</section>

<section>
	<div id="Loggedmenu">
		<a class="create" href="create.php">CREATE TRANSACTION</a><a>|</a>
		<a class="view" href="view.php">VIEW TRANSACTION</a><a>|</a>
		<a class="update" href="update.php">UPDATE TRANSACTION</a>
	</div>
</section>

