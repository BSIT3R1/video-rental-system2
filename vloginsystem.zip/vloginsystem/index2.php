

<?php
	include_once 'header.php';
?>


<section class="main-container">
	<div class="main-wrapper">
		<h2>Signed Up SUCCESSFULLY</h2>
	</div>
</section>


<?php
	include_once 'footer.php';
?>

