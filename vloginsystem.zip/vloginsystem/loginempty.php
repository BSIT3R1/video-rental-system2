<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="style.css">
	<title>Video Rental System</title>
</head>
<body>

</body>
</html>

<?php
	include_once 'header.php';
?>
<section class="main-container">
	<div class="main-wrapper">
		<h2 id = "start">WELCOME TO</h2>
		<h2 id = "start2">Video Rental System</h2>
	</div>
</section>


<?php
	include_once 'footer.php';
?>

<?php
alert("PLEASE input USERNAME and PASSWORD!");

function alert($msg) {
    echo "<script type='text/javascript'>alert('$msg');</script>";
}
?>
