<?php
	include_once 'home.php';
?>


<section class="main-container">
	<div class="main-wrapper">
			<section>
				<li id="menu">
					<a class="create" href="create.php">CREATE TRANSACTION</a>
					<a class="view" href="view.php">VIEW TRANSACTION</a>
					<a class="update" href="update.php">UPDATE TRANSACTION</a>
				</li>
			</section>
		<h2>Create Transaction</h2>
		<form class="create-transaction" action="includes/createtransaction.inc.php" method="POST">
			<input type="Date" name="date" placeholder="Date">
			<input type="text" name="custlast" placeholder="Customer Lastname">
			<input type="text" name="custfirst" placeholder="Customer Firstname">
			<input type="text" name="vidname" placeholder="Video Name">
			<input type="text" name="vidtype" placeholder="Video Type">
			<input type="number" name="price" placeholder="Price">
			<button id="submit" type="submit2" name="Create">Create</button>
		</form>

	</div>
</section>

	
<?php
	include_once 'footer.php'
?>
