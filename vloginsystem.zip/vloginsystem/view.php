<?php
	include_once 'home.php';
?>


<section class="main-container">
	<div class="main-wrapper">
			<section>
				<li id="menu">
					<a class="create" href="create.php">CREATE TRANSACTION</a>
					<a class="view" href="view.php">VIEW TRANSACTION</a>
					<a class="update" href="update.php">UPDATE TRANSACTION</a>
				</li>
			</section>
			<h2>View Transaction</h2>
	</div>
</section>

<section>

 <?php
        //connect to DB
$connection = mysql_connect('localhost', 'root', ''); //The Blank string is the password
mysql_select_db('vloginsystem2');


$query = "SELECT * FROM customer"; 
$result = mysql_query($query);

echo "<table border: '2px'>";
echo "<tr><td>Transaction ID</td><td>Date</td><td>Last Name</td><td>First Name</td><td>Video Name</td><td>Video Type</td><td>Price</td></tr>";
while($row = mysql_fetch_array($result))
  {
  echo "</br><tr><td>" . $row['cust_transid'] . "</td><td>" . $row['cust_date'] . "</td><td>" . $row['cust_custlast'] . "</td><td>" . $row['cust_custfirst'] . "</td><td>" . $row['cust_vidname'] . "</td><td>" . $row['cust_vidtype'] . "</td><td>" . $row['cust_price'] . "</td></br></tr>";
  }
echo "</table>";
mysql_close();
?>
</section>