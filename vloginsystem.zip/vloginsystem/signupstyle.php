<?php
	header('content-type: text/css; charset:UTF-8');
?>
	h2{
	color:black;
}