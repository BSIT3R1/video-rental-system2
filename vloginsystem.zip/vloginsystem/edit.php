<?php
	include_once 'home.php';
?>


<section class="main-container">
	<div class="main-wrapper">
			<section>
				<li id="menu">
					<a class="create" href="create.php">CREATE TRANSACTION</a>
					<a class="view" href="view.php">VIEW TRANSACTION</a>
					<a class="update" href="update.php">UPDATE TRANSACTION</a>
				</li>
			</section>
			<h2>Update Transaction</h2></br></br>
	</div>
</section>

<?php
 if (isset($_GET['edit']))
 {
 	$cust_transid = $_GET['edit'];
 	$res = mysql_query("SELECT * FROM customer");
 	$row = mysql_fetch_array($res);
 }
 if (isset($_POST['newName']))
 {
 	$newName = $_POST['newName'];
 	$cust_transid = $_POST['cust_transid'];
 	$sql = "UPDATE customer SET cust_custlast = '$newName' WHERE cust_transid = '$cust_transid'";
 	$result = mysql_query($sql) or die("FAILED".mysql_error());
 	echo "<meta http-equiv=refresh'content='0;url=update.php'>";
 }
 ?>
 <form action="edit.php" method="POST">
 	Date: <input type=" text" name="newName" value="<?php echo $row[1];?>"><br/>
  	Last Name: <input type=" text" name="newName" value="<?php echo $row[2];?>"><br/>
   	First Name: <input type=" text" name="newName" value="<?php echo $row[3];?>"><br/>
    Video Name: <input type=" text" name="newName" value="<?php echo $row[4];?>"><br/>			
 	Video Type: <input type=" text" name="newName" value="<?php echo $row[5];?>"><br/> 
 	Price: <input type=" text" name="newName" value="<?php echo $row[6];?>"><br/>
 	<input type="hidden" name="cust_transid" value="<?php echo $row[0]; ?>"><br/>
 	<input type="submit" value="UPDATE">
 </form>