<?php
	include_once 'home.php';
?>


<section class="main-container">
	<div class="main-wrapper">
			<section>
				<li id="menu">
					<a class="create" href="create.php">CREATE TRANSACTION</a>
					<a class="view" href="view.php">VIEW TRANSACTION</a>
					<a class="update" href="update.php">UPDATE TRANSACTION</a>
				</li>
			</section>
		<h2>Create Transaction</h2></br></br></br></br>

		<h2>SUCCESSFULLY ADDED !</h2>
	</div>