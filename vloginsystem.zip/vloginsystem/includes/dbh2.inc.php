<?php

$dbServername2 = "localhost";
$dbUsername2 = "root";
$dbPassword2 = "";
$dbName2 = "vloginsystem2";

$conn2 = mysqli_connect($dbServername2, $dbUsername2, $dbPassword2, $dbName2);


?>










