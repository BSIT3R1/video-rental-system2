<?php

if(isset($_POST['Create']))
{

	include_once 'dbh.inc.php';

	$date = mysqli_real_escape_string($conn, $_POST['date']);
	$custlast = mysqli_real_escape_string($conn, $_POST['custlast']);
	$custfirst = mysqli_real_escape_string($conn, $_POST['custfirst']);
	$vidname = mysqli_real_escape_string($conn, $_POST['vidname']);
	$vidtype = mysqli_real_escape_string($conn, $_POST['vidtype']);
	$price = mysqli_real_escape_string($conn, $_POST['price']);


	//ERROR HANDLERS
	//Check for empty fields
	if( empty($date) || empty($custlast) || empty($custfirst) || empty($vidname) || empty($vidtype) || empty($price))
	{
		header("Location: ../createempty.php?create=empty");
		exit();
	}  
	else {
			//check if input characters are valid
			if(!preg_match("/^[a-zA-Z]*$/", $custlast) || !preg_match("/^[a-zA-Z]*$/", $custfirst))
			{
			header("Location: ../createempty.php?create=invalid");
			exit();
			}
	else{

			if ($resultCheck > 0)
			{
				header("Location: ../createempty.php?create=usertaken");
				exit();

			}
			else
			{
				//Insert the user into database
				$sql = "INSERT INTO customer (cust_transid, cust_date, cust_custlast, cust_custfirst, cust_vidname, cust_vidtype, cust_price) VALUES ('$transid', '$date', '$custlast', '$custfirst', '$vidname', '$vidtype', '$price');";
				mysqli_query($conn, $sql);
				header("Location: ../create2.php?create=success");
				exit();
			}
		}
		 }
}
else
{
	header("Location: ../create.php");
	exit();
}